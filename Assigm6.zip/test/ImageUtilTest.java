
/**
 * A test class for the ImageUtil.
 */
public class ImageUtilTest {
  // commented out the test because of the Java Style but it runs

  /*
  // checks if the reader can find the file
  @Test
  public void testLoadPPM() throws FileNotFoundException {
    new FileReader("Res/Koala.ppm");
  }
  */


}
