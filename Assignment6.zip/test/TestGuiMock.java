import org.junit.Test;

import java.awt.event.ActionListener;

import controller.MockGuiController;
import view.GUI;

public class TestGuiMock {

  @Test
  public void test1() {
    GUI view = new GUI();
    StringBuilder log = new StringBuilder();
    ActionListener MockGuiController = new MockGuiController(view, log);
  }
}
